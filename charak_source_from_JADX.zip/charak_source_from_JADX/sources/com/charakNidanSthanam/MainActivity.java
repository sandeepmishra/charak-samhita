package com.charakNidanSthanam;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends FragmentActivity {
    int[] chapterCount;
    List<Fragment> chapterFragments;
    ChapterList chapterList;
    int chaptercount;
    private MyAdapter mAdapter;
    private ViewPager mPager;

    class ChapterList {
        ChapterList() {
        }

        public void addChapter(int pos) {
            MainActivity.this.chapterFragments.addAll(getChapter(pos));
        }

        public List<Fragment> getChapter(int pos) {
            List<Fragment> list = new ArrayList();
            switch (pos) {
                case 0:
                    list.add(new Chapter1Page1());
                    list.add(new Chapter1Page2());
                    list.add(new Chapter1Page3());
                    return list;
                case 1:
                    list.add(new Chapter2Page1());
                    list.add(new Chapter2Page2());
                    return list;
                case 2:
                    list.add(new Chapter3Page1());
                    list.add(new Chapter3Page2());
                    return list;
                case 3:
                    list.add(new Chapter4Page1());
                    list.add(new Chapter4Page2());
                    list.add(new Chapter4Page3());
                    return list;
                case 4:
                    list.add(new Chapter5Page1());
                    list.add(new Chapter5Page2());
                    list.add(new Chapter5Page3());
                    return list;
                case 5:
                    list.add(new Chapter6Page1());
                    list.add(new Chapter6Page2());
                    return list;
                case 6:
                    list.add(new Chapter7Page1());
                    list.add(new Chapter7Page2());
                    return list;
                case 7:
                    list.add(new Chapter8Page1());
                    list.add(new Chapter8Page2());
                    list.add(new Chapter8Page3());
                    return list;
                default:
                    return null;
            }
        }
    }

    public class MyAdapter extends FragmentPagerAdapter {
        public MyAdapter(FragmentManager fm) {
            super(fm);
        }

        public int getCount() {
            return 20;
        }

        public Fragment getItem(int position) {
            switch (position) {
                case 0:
                    return new Chapter1Page1();
                case 1:
                    return new Chapter1Page2();
                case 2:
                    return new Chapter1Page3();
                case 3:
                    return new Chapter2Page1();
                case 4:
                    return new Chapter2Page2();
                case 5:
                    return new Chapter3Page1();
                case 6:
                    return new Chapter3Page2();
                case 7:
                    return new Chapter4Page1();
                case 8:
                    return new Chapter4Page2();
                case 9:
                    return new Chapter4Page3();
                case 10:
                    return new Chapter5Page1();
                case 11:
                    return new Chapter5Page2();
                case 12:
                    return new Chapter5Page3();
                case 13:
                    return new Chapter6Page1();
                case 14:
                    return new Chapter6Page2();
                case 15:
                    return new Chapter7Page1();
                case 16:
                    return new Chapter7Page2();
                case 17:
                    return new Chapter8Page1();
                case 18:
                    return new Chapter8Page2();
                case 19:
                    return new Chapter8Page3();
                default:
                    return null;
            }
        }
    }

    public MainActivity() {
        int[] iArr = new int[8];
        iArr[1] = 3;
        iArr[2] = 5;
        iArr[3] = 7;
        iArr[4] = 10;
        iArr[5] = 13;
        iArr[6] = 15;
        iArr[7] = 17;
        this.chapterCount = iArr;
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0134R.layout.activity_main);
        this.chaptercount = getIntent().getIntExtra("selChapter", 0);
        this.mAdapter = new MyAdapter(getSupportFragmentManager());
        this.chapterFragments = new ArrayList();
        this.mPager = (ViewPager) findViewById(C0134R.id.pager);
        this.mPager.setAdapter(this.mAdapter);
        this.mPager.setCurrentItem(this.chapterCount[this.chaptercount]);
    }
}
