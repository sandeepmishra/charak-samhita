package com.charakNidanSthanam;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Typeface;
import android.support.v4.util.LruCache;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.widget.TextView;

public class CustomFontType extends TextView {
    private static LruCache<String, Typeface> sTypefaceCache = new LruCache(12);

    public CustomFontType(Context context, AttributeSet attrs) {
        super(context, attrs);
        TypedArray a = context.getTheme().obtainStyledAttributes(attrs, C0134R.styleable.Tahoma, 0, 0);
        try {
            String typefaceName = a.getString(0);
            if (!(isInEditMode() || TextUtils.isEmpty(typefaceName))) {
                Typeface typeface = (Typeface) sTypefaceCache.get(typefaceName);
                if (typeface == null) {
                    typeface = Typeface.createFromAsset(context.getAssets(), String.format("fonts/%s.ttf", new Object[]{typefaceName}));
                    sTypefaceCache.put(typefaceName, typeface);
                }
                setTypeface(typeface);
                setPaintFlags(getPaintFlags() | 128);
            }
            a.recycle();
        } catch (Throwable th) {
            a.recycle();
        }
    }
}
