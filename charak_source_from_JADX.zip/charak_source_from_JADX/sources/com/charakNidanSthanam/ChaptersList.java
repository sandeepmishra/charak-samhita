package com.charakNidanSthanam;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import java.util.ArrayList;
import java.util.List;

public class ChaptersList extends ListActivity {
    int[] chapterlistArr = new int[]{C0134R.string.chapter1, C0134R.string.chapter2, C0134R.string.chapter3, C0134R.string.chapter4, C0134R.string.chapter5, C0134R.string.chapter6, C0134R.string.chapter7, C0134R.string.chapter8};
    List<String> chaptersList;

    class OnChapterItemClickListener implements OnItemClickListener {
        OnChapterItemClickListener() {
        }

        public void onItemClick(AdapterView<?> adapterView, View arg1, int position, long arg3) {
            Intent intent = new Intent(ChaptersList.this, MainActivity.class);
            intent.putExtra("selChapter", position);
            ChaptersList.this.startActivity(intent);
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0134R.layout.chapters_list);
        this.chaptersList = new ArrayList();
        for (int i = 0; i <= 7; i++) {
            this.chaptersList.add(getString(this.chapterlistArr[i]));
        }
        setListAdapter(new ArrayAdapter(this, C0134R.layout.list_adapter_style, C0134R.id.text1, this.chaptersList));
        getListView().setOnItemClickListener(new OnChapterItemClickListener());
    }
}
